================================================================================
|     __________             .___.______  _______  _______ ____                |
|     \______   \_____     __| _/|__\   \/  /\   \/  /_   /_   |               |
|      |       _/\__  \   / __ | |  |\     /  \     / |   ||   |               |
|      |    |   \ / __ \_/ /_/ | |  |/     \  /     \ |   ||   |               |
|      |____|_  /(____  /\____ | |__/___/\  \/___/\  \|___||___|               |
|             \/      \/      \/          \_/      \_/           [ 2019 ]      |
+------------------------------------------------------------------------------+

==[ RELEASE INFO ]==============================================================
|                                                                              |
| > Name......: NCH Software Keygen                                            |
| > Date......: 2019-04-19                                                     |
| > Version...: 1.5                                                            |
| > File......: Keygen.exe                                                     |
| > MD5.......: ee315a685c5072bd772611804f66e00d                               |
| > SHA1......: 8f3a587e7c25162d95201359050f644401a1e425                       |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET INFO ]===============================================================
|                                                                              |
| > Category..: Misc. Tools                                                    |
| > Protection: Serial/Custom                                                  |
| > OS........: WinALL                                                         |
| > Homepage..: http://www.nchsoftware.com - http://www.nch.com.au             |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET DESCRIPTION ]========================================================
|                                                                              |
| NCH Software is a leader in business audio technology. Since 1993 has        |
| released more than 80 easy-to-use software applications for Windows, Mac and |
| mobile devices. Each software program is designed to fulfill a specific need |
| and many programs are considered leaders in their markets and have been      |
| awarded for excellence.                                                      |
|                                                                              |
| Software categories include applications for audio, video, business,         |
| dictation and other software utilities. By offering such a wide breadth of   |
| software applications at affordable prices, NCH Software is where users turn |
| for reliable software applications for any need. NCH Software continues to   |
| develop new programs while maintaining focus on developing easy-to-use,      |
| simple software solutions.                                                   |
|                                                                              |
+------------------------------------------------------------------------------+

==[ HOW TO USE ]================================================================
|                                                                              |
| 1. Click "Patch Hosts" to block license validation (product releases from    |
| 2018 and later) or use a firewall (see first note below).                    |
|                                                                              |
| 2. Select the target product and disconnect from Internet if required (see   |
| second note below).                                                          |
|                                                                              |
| 3. Some products will require extra information: "Name"/"User Name" and      |
| "Location"/"User E-Mail". You must complete these fields before generate an  |
| ID-Key. The rest of the products doesn't require any user information, but   |
| you can especify (OPTIONAL) a "Licensed User" name, that will be shown in    |
| the "About ..." dialog box and in the title bar of each product: enter the   |
| desired name and click "Save" to write the name to the registry.             |
|                                                                              |
| 4. Click "Generate". Use "Copy" to copy the full ID-Key or right click over  |
| the fields to copy each part separately.                                     |
|                                                                              |
| 5. Use the generated ID-Key to register the program. If the ID-Key is        |
| rejected, enable "Use new format", generate a new ID-Key and try again.      |
|                                                                              |
| NOTES:                                                                       |
|                                                                              |
| - In case you don't want to patch your hosts file, use a firewall to block   |
| any outgoing connection to: secure.nch.com.au                                |
|                                                                              |
| - Some old products will perform an online validation of the license info at |
| the time of registration (the keygen will warn you about wich products do    |
| this every time you pick one). To avoid this just disconnect from Internet   |
| before register. On these products, the validation is performed only the     |
| firt time you register the program. For products releases from 2018 and      |
| later, you will need a permanent block with a hosts file patch or firewall   |
| rule (see first note).                                                       |
|                                                                              |
| - If you have 2 options for registration: "Register New User..." and         |
| "Register Site License...", ALWAYS USE THE LAST ONE.                         |
|                                                                              |
| - After registration, if you can't see "Licensed software"/"Licensed User"   |
| or something like that in the title bar and/or "About" window, RESTART THE   |
| PROGRAM (don't forget to check the system tray).                             |
|                                                                              |
| - With some products, the "Register software..." and "Purchase online"       |
| options still available after register them. Just ignore it, it's perfectly  |
| normal.                                                                      |
|                                                                              |
+------------------------------------------------------------------------------+

==[ UPDATES & FIXES ]===========================================================
|                                                                              |
| To get the most recent version of this release, go to Options menu (little   |
| button with a down arrow at top-right corner) -> "Check for updates" or just |
| visit the site listed at the end (recommended).                              |
|                                                                              |
+------------------------------------------------------------------------------+

==[ FOR EVALUATION PURPOSES ONLY ]==============================================
|                                                                              |
| If you can afford it, please BUY IT. Support the developer to make a better  |
| product.                                                                     |
|                                                                              |
+------------------------------------------------------------------------------+

==[ RELEASES & SOURCE CODES ]===================================================
|                                                                              |
| https://radixx11rce2.blogspot.com                                            |
|                                                                              |
+------------------------------------------------------------------------------+
